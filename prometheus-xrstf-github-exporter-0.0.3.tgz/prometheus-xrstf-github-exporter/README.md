
# prometheus-xrstf-github-exporter

## `license`
```
          ,-.
 ,     ,-.   ,-.
/ \   (   )-(   )
\ |  ,.>-(   )-<
 \|,' (   )-(   )
  Y ___`-'   `-'
  |/__/   `-'
  |
  |
  |    -hi-
__|_____________

/* Copyright (C) Saritasa,LLC - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Saritasa Devops Team, April 2022
 */

```

## `chart.deprecationWarning`

## `chart.name`

prometheus-xrstf-github-exporter

## `chart.version`

![Version: 0.0.3](https://img.shields.io/badge/Version-0.0.3-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Saritasa | <nospam@saritasa.com> | <https://www.saritasa.com/> |

## `chart.description`

A Helm chart for Kubernetes to a github stats exporter for Prometheus.

You will need to create the secret containing Github token first:
The token must have permissions to:
"Read access to code, issues, metadata, and pull requests, actions"
in all the repositories to be scrapped
```sh
kubectl -n prometheus create secret generic github-token \
  --from-literal=token=YOUR_TOKEN

## `chart.valuesTable`

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| args[0] | string | `"-repo=xrstf/github_exporter"` |  |
| existingSecret | string | `"github-token"` | existing secret with token for Github API |
| fullnameOverride | string | `""` |  |
| image.pullPolicy | string | `"IfNotPresent"` | pull policy |
| image.repository | string | `"xrstf/github_exporter"` | default docker registry |
| image.tag | string | `"0.4.0"` | Overrides the image tag whose default is the chart appVersion. |
| imagePullSecrets | list | `[]` | docker pull secret |
| nameOverride | string | `""` |  |
| nodeSelector."kubernetes.io/arch" | string | `"amd64"` |  |
| podAnnotations | object | `{}` |  |
| podSecurityContext | object | `{}` |  |
| replicaCount | int | `1` |  |
| resources.requests.cpu | string | `"50m"` |  |
| resources.requests.memory | string | `"50Mi"` |  |
| securityContext | object | `{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000}` | security options for the running pod |
| service | object | `{"port":9162,"type":"ClusterIP"}` | type of the service to create |
| tolerations | list | `[]` |  |
